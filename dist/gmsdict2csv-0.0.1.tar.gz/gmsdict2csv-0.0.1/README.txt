GMS dict2csv
Convert a list to a csv file.
This python package takes a list and an output folder in which to create the csv file.